package de.fristfox.app;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Insets;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String DEFAULT_URL = "https://fristfox.de/app.php?native=android&app_version=1.0.2";
    private static final int NOTIFICATION_PERMISSION_REQUEST = 4102;
    private static final int DEVICE_CREDENTIAL_REQUEST = 4103;
    private static final int FILE_CHOOSER_REQUEST = 4104;

    private FrameLayout rootView;
    private WebView webView;
    private AppLockManager appLockManager;
    private ValueCallback<Uri[]> filePathCallback;
    private boolean authenticatedThisForeground = false;
    private boolean authenticationInProgress = false;
    private boolean biometricFallbackUsed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        appLockManager = new AppLockManager(this);
        createWebView();
        configureSystemBars();
        registerPredictiveBack();
        loadFromIntent(getIntent());
    }

    private void createWebView() {
        rootView = new FrameLayout(this);
        rootView.setBackgroundColor(Color.rgb(17, 24, 39));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.TRANSPARENT);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        rootView.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(rootView);
        configureWebView();
    }

    private void configureSystemBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            Window window = getWindow();
            window.setDecorFitsSystemWindows(false);
            hideStatusBar();

            // Wichtig: Die WebView selbst darf nicht nur Padding erhalten.
            // Ein fest positioniertes Web-Menü ignoriert WebView-Padding teilweise.
            // Deshalb reserviert der native Container den Platz der Android-
            // Navigationsleiste; das FristFox-Menü bleibt vollständig sichtbar.
            rootView.setOnApplyWindowInsetsListener((v, insets) -> {
                Insets nav = insets.getInsets(WindowInsets.Type.navigationBars());
                Insets cutout = insets.getInsets(WindowInsets.Type.displayCutout());
                int left = Math.max(nav.left, cutout.left);
                int right = Math.max(nav.right, cutout.right);
                int top = cutout.top;
                v.setPadding(left, top, right, nav.bottom);
                return insets;
            });
            rootView.requestApplyInsets();
        } else {
            getWindow().setFlags(
                    WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
            rootView.setFitsSystemWindows(true);
        }
    }

    private void hideStatusBar() {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars());
                controller.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideStatusBar();
    }

    private void registerPredictiveBack() {
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                    this::handleBack);
        }
    }

    private void configureWebView() {
        WebView.setWebContentsDebuggingEnabled(false);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setUserAgentString(settings.getUserAgentString() + " FristFoxAndroid/1.0.2");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) settings.setSafeBrowsingEnabled(true);

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView, false);

        webView.addJavascriptInterface(new FristFoxBridge(this), "FristFoxNative");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePath,
                                             FileChooserParams fileChooserParams) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = filePath;
                try {
                    Intent intent = fileChooserParams.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "Dateiauswahl konnte nicht geöffnet werden.", Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (isTrustedFristFoxUri(uri)) return false;
                openExternal(uri);
                return true;
            }

            @SuppressWarnings("deprecation")
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Uri uri = Uri.parse(url);
                if (isTrustedFristFoxUri(uri)) return false;
                openExternal(uri);
                return true;
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                // TLS-Fehler niemals umgehen.
                handler.cancel();
            }

        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) ->
                downloadTrustedFile(url, userAgent, contentDisposition, mimeType));
    }

    private boolean isTrustedFristFoxUri(Uri uri) {
        if (uri == null || !"https".equalsIgnoreCase(uri.getScheme())) return false;
        String host = uri.getHost();
        return "fristfox.de".equalsIgnoreCase(host) || "www.fristfox.de".equalsIgnoreCase(host);
    }

    private void openExternal(Uri uri) {
        if (uri == null) return;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception ignored) {
            Toast.makeText(this, "Kein passender Dienst gefunden.", Toast.LENGTH_SHORT).show();
        }
    }

    private void downloadTrustedFile(String url, String userAgent, String contentDisposition, String mimeType) {
        Uri uri;
        try { uri = Uri.parse(url); } catch (Exception e) { return; }
        if (!isTrustedFristFoxUri(uri)) {
            openExternal(uri);
            return;
        }
        try {
            DownloadManager.Request request = new DownloadManager.Request(uri);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null && !cookie.isEmpty()) request.addRequestHeader("Cookie", cookie);
            if (userAgent != null && !userAgent.isEmpty()) request.addRequestHeader("User-Agent", userAgent);
            if (mimeType != null && !mimeType.isEmpty()) request.setMimeType(mimeType);
            String fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
                    .replaceAll("[\\\\/:*?\"<>|]", "_");
            if (fileName.length() > 120) fileName = fileName.substring(fileName.length() - 120);
            request.setTitle(fileName);
            request.setDescription("FristFox-Dokument wird heruntergeladen");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            if (Build.VERSION.SDK_INT >= 29) {
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
            } else {
                request.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, fileName);
            }
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm != null) {
                dm.enqueue(request);
                Toast.makeText(this, "Download gestartet", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Download konnte nicht gestartet werden.", Toast.LENGTH_LONG).show();
        }
    }

    private void loadFromIntent(Intent intent) {
        Uri data = intent != null ? intent.getData() : null;
        String target = DEFAULT_URL;
        if (isTrustedFristFoxUri(data)) {
            Uri.Builder builder = data.buildUpon();
            if (data.getQueryParameter("native") == null) builder.appendQueryParameter("native", "android");
            if (data.getQueryParameter("app_version") == null) builder.appendQueryParameter("app_version", "1.0.2");
            target = builder.build().toString();
        }
        webView.loadUrl(target);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        loadFromIntent(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (appLockManager.isEnabled() && !authenticatedThisForeground && !authenticationInProgress) {
            webView.setVisibility(View.INVISIBLE);
            startAuthentication();
        } else if (!appLockManager.isEnabled()) {
            webView.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (!authenticationInProgress && !isChangingConfigurations()) {
            authenticatedThisForeground = false;
            biometricFallbackUsed = false;
        }
    }

    private void startAuthentication() {
        authenticationInProgress = true;
        boolean started = appLockManager.tryBiometric(this::authenticationSucceeded, this::startCredentialFallback);
        if (!started) startCredentialFallback();
    }

    private void startCredentialFallback() {
        if (biometricFallbackUsed) {
            authenticationFailed();
            return;
        }
        biometricFallbackUsed = true;
        Intent intent = appLockManager.createCredentialIntent();
        if (intent == null) {
            authenticationFailed();
            return;
        }
        try {
            startActivityForResult(intent, DEVICE_CREDENTIAL_REQUEST);
        } catch (Exception ignored) {
            authenticationFailed();
        }
    }

    private void authenticationSucceeded() {
        runOnUiThread(() -> {
            authenticationInProgress = false;
            authenticatedThisForeground = true;
            biometricFallbackUsed = false;
            webView.setVisibility(View.VISIBLE);
        });
    }

    private void authenticationFailed() {
        runOnUiThread(() -> {
            authenticationInProgress = false;
            authenticatedThisForeground = false;
            webView.setVisibility(View.INVISIBLE);
            finishAndRemoveTask();
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == DEVICE_CREDENTIAL_REQUEST) {
            if (resultCode == RESULT_OK) authenticationSucceeded();
            else authenticationFailed();
            return;
        }
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback != null) {
                Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                filePathCallback.onReceiveValue(result);
                filePathCallback = null;
            }
        }
    }

    private void handleBack() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else finish();
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (Build.VERSION.SDK_INT < 33) handleBack();
        else super.onBackPressed();
    }

    public String requestNotificationPermissionFromBridge() {
        if (Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            getSharedPreferences("fristfox_native", MODE_PRIVATE).edit().putBoolean("notifications_enabled", true).apply();
            ReminderScheduler.rescheduleFromStored(this);
            return "true";
        }
        runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST));
        return "pending";
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == NOTIFICATION_PERMISSION_REQUEST) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            getSharedPreferences("fristfox_native", MODE_PRIVATE).edit().putBoolean("notifications_enabled", granted).apply();
            if (granted) ReminderScheduler.rescheduleFromStored(this); else ReminderScheduler.disableAll(this);
            final String js = "window.FristFoxNativePermissionResult&&window.FristFoxNativePermissionResult(" + (granted ? "true" : "false") + ")";
            webView.post(() -> webView.evaluateJavascript(js, null));
        }
    }

    @Override
    protected void onDestroy() {
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
        }
        if (webView != null) {
            webView.removeJavascriptInterface("FristFoxNative");
            webView.stopLoading();
            webView.clearHistory();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
