package de.fristfox.app;

import android.app.Activity;
import android.app.KeyguardManager;
import android.hardware.biometrics.BiometricPrompt;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.CancellationSignal;
import android.widget.Toast;

public class AppLockManager {
    private static final String PREFS = "fristfox_native";
    private static final String KEY_ENABLED = "app_lock_enabled";
    private final Activity activity;

    public AppLockManager(Activity activity) {
        this.activity = activity;
    }

    public boolean isEnabled() {
        return activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false);
    }

    public boolean canUseDeviceSecurity() {
        KeyguardManager km = (KeyguardManager) activity.getSystemService(Context.KEYGUARD_SERVICE);
        return km != null && km.isDeviceSecure();
    }

    public boolean setEnabled(boolean enabled) {
        if (enabled && !canUseDeviceSecurity()) {
            activity.runOnUiThread(() -> Toast.makeText(activity,
                    "Bitte zuerst eine Displaysperre (PIN, Passwort oder Biometrie) in Android einrichten.",
                    Toast.LENGTH_LONG).show());
            return false;
        }
        activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, enabled).apply();
        return true;
    }

    /**
     * Nutzt ab Android 9 die systemeigene Biometrie. Ab Android 10 darf Android alternativ
     * direkt die Geräte-PIN/das Gerätepasswort anbieten. Bei älteren/ungeeigneten Geräten
     * fällt MainActivity auf die normale Android-Gerätebestätigung zurück.
     */
    public boolean tryBiometric(Runnable success, Runnable fallbackOrCancel) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return false;
        try {
            BiometricPrompt.Builder builder = new BiometricPrompt.Builder(activity)
                    .setTitle("FristFox entsperren")
                    .setSubtitle("Bestätige deine Identität");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                builder.setDeviceCredentialAllowed(true);
            } else {
                builder.setNegativeButton("PIN verwenden", activity.getMainExecutor(), (dialog, which) -> fallbackOrCancel.run());
            }
            BiometricPrompt prompt = builder.build();
            CancellationSignal signal = new CancellationSignal();
            prompt.authenticate(signal, activity.getMainExecutor(), new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                    success.run();
                }

                @Override
                public void onAuthenticationError(int errorCode, CharSequence errString) {
                    fallbackOrCancel.run();
                }
            });
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    public Intent createCredentialIntent() {
        KeyguardManager km = (KeyguardManager) activity.getSystemService(Context.KEYGUARD_SERVICE);
        if (km == null || !km.isDeviceSecure()) return null;
        return km.createConfirmDeviceCredentialIntent(
                "FristFox entsperren",
                "Bestätige deine PIN, dein Passwort oder die Gerätesperre, um FristFox zu öffnen."
        );
    }
}
