package de.fristfox.app;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "fristfox_reminders";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!context.getSharedPreferences("fristfox_native", Context.MODE_PRIVATE).getBoolean("notifications_enabled", false)) return;
        String uuid = intent.getStringExtra("uuid");
        String title = intent.getStringExtra("title");
        String dueDate = intent.getStringExtra("due_date");
        int days = intent.getIntExtra("days_before", 0);
        boolean persistent = intent.getBooleanExtra("persistent", false);
        if (uuid == null || uuid.isEmpty()) return;
        if (title == null || title.isEmpty()) title = "FristFox Erinnerung";

        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        ensureChannel(manager);

        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;

        Uri deepLink = Uri.parse("https://fristfox.de/app.php?focus=" + Uri.encode(uuid) + "&native=android");
        Intent open = new Intent(context, MainActivity.class)
                .setAction(Intent.ACTION_VIEW)
                .setData(deepLink)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(context, stableId(uuid), open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        String body;
        if (persistent) body = "Diese Frist ist fällig oder überfällig. Öffne FristFox, um sie zu erledigen.";
        else if (days == 0) body = "Heute fällig";
        else if (days == 1) body = "Morgen fällig";
        else body = "In " + days + " Tagen fällig";
        if (dueDate != null && !dueDate.isEmpty()) {
            try {
                String formatted = LocalDate.parse(dueDate).format(DateTimeFormatter.ofPattern("dd.MM.yyyy"));
                body += " · " + formatted;
            } catch (Exception ignored) { }
        }

        android.app.Notification notification = new android.app.Notification.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new android.app.Notification.BigTextStyle().bigText(body))
                .setContentIntent(contentIntent)
                .setAutoCancel(true)
                .setCategory(android.app.Notification.CATEGORY_REMINDER)
                .setVisibility(android.app.Notification.VISIBILITY_PRIVATE)
                .build();
        manager.notify(stableId(uuid + ":" + System.currentTimeMillis() / 60000L), notification);
    }

    public static void ensureChannel(NotificationManager manager) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Frist-Erinnerungen", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Lokale FristFox-Erinnerungen auf diesem Gerät");
            manager.createNotificationChannel(channel);
        }
    }

    private static int stableId(String value) {
        return 0x3fffffff & value.hashCode();
    }
}
