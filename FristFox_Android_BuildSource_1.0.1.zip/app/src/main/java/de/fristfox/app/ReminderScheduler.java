package de.fristfox.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class ReminderScheduler {
    private static final String PREFS = "fristfox_native";
    private static final String KEY_ALARM_IDS = "alarm_ids";
    private static final String KEY_NOTIFICATIONS_ENABLED = "notifications_enabled";
    private static final long DAY_MS = 24L * 60L * 60L * 1000L;

    private ReminderScheduler() { }

    public static void scheduleAll(Context context, String json) {
        AlarmManager alarms = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarms == null) return;
        cancelAll(context, alarms);
        if (!context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_NOTIFICATIONS_ENABLED, false)) return;
        Set<String> alarmIds = new HashSet<>();

        try {
            JSONArray rows = new JSONArray(json == null ? "[]" : json);
            for (int i = 0; i < rows.length(); i++) {
                JSONObject row = rows.optJSONObject(i);
                if (row == null) continue;
                String uuid = row.optString("uuid", "");
                String title = row.optString("title", "FristFox Erinnerung");
                String due = row.optString("due_date", "");
                String dueTime = row.optString("due_time", "");
                String type = row.optString("type", "frist");
                String reminderDays = row.optString("reminder_days", "");
                boolean untilDone = row.optInt("remind_until_done", 0) == 1;
                if (uuid.isEmpty() || due.isEmpty()) continue;

                LocalDate dueDate;
                try { dueDate = LocalDate.parse(due); } catch (Exception ignored) { continue; }
                LocalTime time = parseTimeOrDefault(dueTime, LocalTime.of(9, 0));
                long dueMillis = LocalDateTime.of(dueDate, time).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();

                List<Integer> days = parseDays(reminderDays);
                if (days.isEmpty()) days.add(0);
                for (int day : days) {
                    long trigger = LocalDateTime.of(dueDate.minusDays(Math.max(day, 0)), time)
                            .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
                    if (trigger <= System.currentTimeMillis()) continue;
                    String alarmId = uuid + ":d:" + day;
                    int requestCode = stableRequestCode(alarmId);
                    PendingIntent pi = reminderPendingIntent(context, requestCode, uuid, title, type, due, day, false);
                    alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
                    alarmIds.add(alarmId);
                }

                if (untilDone) {
                    long first = dueMillis;
                    if (first <= System.currentTimeMillis()) {
                        LocalDateTime next = LocalDateTime.now().withHour(time.getHour()).withMinute(time.getMinute()).withSecond(0).withNano(0);
                        if (!next.isAfter(LocalDateTime.now())) next = next.plusDays(1);
                        first = next.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
                    }
                    String alarmId = uuid + ":until_done";
                    int requestCode = stableRequestCode(alarmId);
                    PendingIntent pi = reminderPendingIntent(context, requestCode, uuid, title, type, due, 0, true);
                    alarms.setInexactRepeating(AlarmManager.RTC_WAKEUP, first, DAY_MS, pi);
                    alarmIds.add(alarmId);
                }
            }
        } catch (Exception ignored) { }

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putStringSet(KEY_ALARM_IDS, alarmIds).apply();
    }

    public static void rescheduleFromStored(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        scheduleAll(context, SecureStore.getString(context, "entries_json", "[]"));
    }

    public static void disableAll(Context context) {
        AlarmManager alarms = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarms != null) cancelAll(context, alarms);
    }

    private static void cancelAll(Context context, AlarmManager alarms) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        Set<String> ids = new HashSet<>(prefs.getStringSet(KEY_ALARM_IDS, new HashSet<>()));
        for (String alarmId : ids) {
            int requestCode = stableRequestCode(alarmId);
            Intent intent = new Intent(context, ReminderReceiver.class).setAction("de.fristfox.app.REMINDER");
            PendingIntent pi = PendingIntent.getBroadcast(context, requestCode, intent,
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (pi != null) {
                alarms.cancel(pi);
                pi.cancel();
            }
        }
        prefs.edit().remove(KEY_ALARM_IDS).apply();
    }

    private static PendingIntent reminderPendingIntent(Context context, int requestCode, String uuid, String title,
                                                        String type, String dueDate, int days, boolean persistent) {
        Intent intent = new Intent(context, ReminderReceiver.class)
                .setAction("de.fristfox.app.REMINDER")
                .putExtra("uuid", uuid)
                .putExtra("title", title)
                .putExtra("type", type)
                .putExtra("due_date", dueDate)
                .putExtra("days_before", days)
                .putExtra("persistent", persistent);
        return PendingIntent.getBroadcast(context, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static LocalTime parseTimeOrDefault(String value, LocalTime fallback) {
        if (value == null || value.isEmpty()) return fallback;
        try {
            if (value.length() == 5) return LocalTime.parse(value + ":00");
            return LocalTime.parse(value);
        } catch (Exception ignored) { return fallback; }
    }

    private static List<Integer> parseDays(String value) {
        List<Integer> out = new ArrayList<>();
        if (value == null || value.trim().isEmpty()) return out;
        for (String part : value.split(",")) {
            try {
                int v = Integer.parseInt(part.trim());
                if (v >= 0 && v <= 365 && !out.contains(v)) out.add(v);
            } catch (NumberFormatException ignored) { }
        }
        return out;
    }

    private static int stableRequestCode(String value) {
        return 0x3fffffff & value.hashCode();
    }
}
