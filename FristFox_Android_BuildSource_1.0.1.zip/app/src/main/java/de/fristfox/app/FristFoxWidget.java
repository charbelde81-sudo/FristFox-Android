package de.fristfox.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class FristFoxWidget extends AppWidgetProvider {
    private static final String PREFS = "fristfox_native";

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) updateOne(context, manager, id);
    }

    public static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName provider = new ComponentName(context, FristFoxWidget.class);
        int[] ids = manager.getAppWidgetIds(provider);
        for (int id : ids) updateOne(context, manager, id);
    }

    private static void updateOne(Context context, AppWidgetManager manager, int widgetId) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_fristfox);
        LocalDate today = LocalDate.now();
        views.setTextViewText(R.id.widgetDate, today.format(DateTimeFormatter.ofPattern("EEEE, dd.MM.yyyy")));

        String json = SecureStore.getString(context, "entries_json", "[]");
        List<WidgetItem> items = parseItems(json, today);
        int[] lineIds = {R.id.widgetLine1, R.id.widgetLine2, R.id.widgetLine3};
        for (int i = 0; i < lineIds.length; i++) {
            if (i < items.size()) views.setTextViewText(lineIds[i], items.get(i).line());
            else if (i == 0) views.setTextViewText(lineIds[i], "✓ Nichts Dringendes");
            else views.setTextViewText(lineIds[i], "");
        }

        Uri link = Uri.parse("https://fristfox.de/app.php?native=android");
        Intent open = new Intent(context, MainActivity.class).setAction(Intent.ACTION_VIEW).setData(link);
        PendingIntent pi = PendingIntent.getActivity(context, 9201, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widgetRoot, pi);
        manager.updateAppWidget(widgetId, views);
    }

    private static List<WidgetItem> parseItems(String json, LocalDate today) {
        List<WidgetItem> list = new ArrayList<>();
        try {
            JSONArray rows = new JSONArray(json == null ? "[]" : json);
            for (int i = 0; i < rows.length(); i++) {
                JSONObject row = rows.optJSONObject(i);
                if (row == null) continue;
                String dueRaw = row.optString("due_date", "");
                if (dueRaw.isEmpty()) continue;
                LocalDate due;
                try { due = LocalDate.parse(dueRaw); } catch (Exception ignored) { continue; }
                // Widgets show today's tasks first, then the next upcoming deadlines.
                if (due.isBefore(today.minusDays(30))) continue;
                String title = row.optString("title", "Frist");
                String time = row.optString("due_time", "");
                String type = row.optString("type", "frist");
                list.add(new WidgetItem(title, due, time, type, today));
            }
        } catch (Exception ignored) { }
        list.sort(Comparator.comparing((WidgetItem x) -> x.due).thenComparing(x -> x.timeSort));
        return list.size() > 3 ? new ArrayList<>(list.subList(0, 3)) : list;
    }

    private static class WidgetItem {
        final String title;
        final LocalDate due;
        final String time;
        final LocalTime timeSort;
        final String type;
        final LocalDate today;

        WidgetItem(String title, LocalDate due, String time, String type, LocalDate today) {
            this.title = title;
            this.due = due;
            this.time = time == null ? "" : time;
            LocalTime parsed;
            try { parsed = this.time.isEmpty() ? LocalTime.of(23,59) : LocalTime.parse(this.time.length()==5?this.time+":00":this.time); }
            catch (Exception ignored) { parsed = LocalTime.of(23,59); }
            this.timeSort = parsed;
            this.type = type;
            this.today = today;
        }

        String line() {
            String prefix;
            if (due.equals(today)) prefix = time.isEmpty() ? "Heute" : time;
            else if (due.equals(today.plusDays(1))) prefix = "Morgen";
            else if (due.isBefore(today)) prefix = "Überfällig";
            else prefix = due.format(DateTimeFormatter.ofPattern("dd.MM."));
            return prefix + " · " + title;
        }
    }
}
