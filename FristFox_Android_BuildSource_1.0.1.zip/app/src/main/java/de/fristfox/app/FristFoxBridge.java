package de.fristfox.app;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.webkit.JavascriptInterface;

public class FristFoxBridge {
    private static final String PREFS = "fristfox_native";
    private static final String KEY_ENTRIES_JSON = "entries_json";
    private final Activity activity;
    private final AppLockManager lockManager;

    public FristFoxBridge(Activity activity) {
        this.activity = activity;
        this.lockManager = new AppLockManager(activity);
    }

    @JavascriptInterface
    public void syncEntries(String json) {
        if (json == null || json.length() > 2_000_000) return;
        if (!SecureStore.putString(activity, KEY_ENTRIES_JSON, json)) return;
        ReminderScheduler.scheduleAll(activity, json);
        FristFoxWidget.updateAll(activity);
    }

    @JavascriptInterface
    public String getAppLockState() {
        return lockManager.isEnabled() ? "true" : "false";
    }

    @JavascriptInterface
    public String setAppLock(boolean enabled) {
        boolean ok = lockManager.setEnabled(enabled);
        return ok && enabled ? "true" : "false";
    }

    @JavascriptInterface
    public String getNotificationState() {
        boolean enabled = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean("notifications_enabled", false);
        if (!enabled) return "false";
        if (Build.VERSION.SDK_INT >= 33 && activity.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) return "false";
        NotificationManager nm = (NotificationManager) activity.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null && !nm.areNotificationsEnabled()) return "false";
        return "true";
    }

    @JavascriptInterface
    public String setNotificationsEnabled(boolean enabled) {
        if (!enabled) {
            activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putBoolean("notifications_enabled", false).apply();
            ReminderScheduler.disableAll(activity);
            return "false";
        }
        return ((MainActivity) activity).requestNotificationPermissionFromBridge();
    }
}
