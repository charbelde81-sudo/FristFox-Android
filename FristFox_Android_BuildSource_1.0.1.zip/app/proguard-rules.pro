-keepclassmembers class de.fristfox.app.FristFoxBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class de.fristfox.app.ReminderReceiver { *; }
-keep class de.fristfox.app.BootReceiver { *; }
-keep class de.fristfox.app.FristFoxWidget { *; }
