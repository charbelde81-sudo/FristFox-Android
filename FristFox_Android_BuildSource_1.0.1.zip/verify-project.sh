#!/usr/bin/env bash
set -euo pipefail
printf 'FristFox Android project sanity check\n'
grep -q "compileSdk 36" app/build.gradle
grep -q "targetSdk 36" app/build.gradle
grep -q "versionName '1.0.1'" app/build.gradle
grep -q "android:usesCleartextTraffic="false"" app/src/main/AndroidManifest.xml
! grep -Rqi "firebase" app/src/main build.gradle app/build.gradle || { echo 'Firebase reference found'; exit 1; }
echo 'OK'
